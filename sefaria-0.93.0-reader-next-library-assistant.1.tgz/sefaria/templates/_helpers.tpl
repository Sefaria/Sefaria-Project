{{- define "sefaria.secrets.googleClient" }}
{{- if .Values.web.secrets.googleClient.ref -}}
{{- .Values.web.secrets.googleClient.ref }}
{{- else -}}
google-client-secret-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- /*
Redis/Sentinel password secretRefs, for an envFrom: list. Every Django process needs them,
since CACHES and GenCache connect to Redis, not just the Celery tasks pod.
*/ -}}
{{- define "sefaria.secrets.redisSentinel" }}
- secretRef:
    name: {{ .Values.tasks.redis.sentinelPassword.ref }}
- secretRef:
    name: {{ .Values.tasks.redis.redisPassword.ref }}
{{- end }}

{{- define "sefaria.secrets.backupManager" }}
{{- if .Values.secrets.backupManager.ref -}}
{{- .Values.secrets.backupManager.ref }}
{{- else -}}
backup-manager-secret-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.secrets.logging" }}
{{- if .Values.web.secrets.logging.ref -}}
{{- .Values.web.secrets.logging.ref }}
{{- else -}}
logging-secret-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.secrets.varnish" }}
{{- if .Values.varnish.secrets.varnish.ref -}}
{{- .Values.varnish.secrets.varnish.ref }}
{{- else -}}
varnish-secret-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.secrets.schoolLookup" }}
{{- if .Values.web.secrets.schoolLookup.ref -}}
{{- .Values.web.secrets.schoolLookup.ref }}
{{- else -}}
school-lookup-data-{{ .Values.deployEnv }}
{{- end }}
{{- end }}


{{- define "sefaria.secrets.elasticCertificate" }}
{{- if .Values.web.secrets.elasticCertificate.ref -}}
{{- .Values.web.secrets.elasticCertificate.ref }}
{{- else -}}
elastic-certificate-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.secrets.elasticUser" }}
{{- if .Values.secrets.elasticUser.ref -}}
{{- .Values.secrets.elasticUser.ref }}
{{- else -}}
elastic-user-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.secrets.elasticAdmin" }}
{{- if .Values.secrets.elasticAdmin.ref -}}
{{- .Values.secrets.elasticAdmin.ref }}
{{- else -}}
elastic-admin-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.secrets.pgvectorPassword" }}
{{- if .Values.secrets.pgvectorPassword.ref -}}
{{- .Values.secrets.pgvectorPassword.ref }}
{{- else -}}
pgvector-secret-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.secrets.geminiApiKey" }}
{{- if .Values.secrets.geminiApiKey.ref -}}
{{- .Values.secrets.geminiApiKey.ref }}
{{- else -}}
gemini-api-key-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.tarballName" }}
{{- if .Values.restore.tarball -}}
{{- .Values.restore.tarball }}
{{- else -}}
private_dump_small_{{ now | date "02.01.06" }}.tar.gz
{{- end }}
{{- end }}

{{/*
Expand the name of the chart.
*/}}
{{- define "sefaria.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "sefaria.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "sefaria.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "sefaria.labels" -}}
helm.sh/chart: {{ include "sefaria.chart" . }}
{{ include "sefaria.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "sefaria.selectorLabels" -}}
app.kubernetes.io/name: {{ include "sefaria.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Scheduling affinites applied to all pods
*/}}
{{- define "sefaria.nodeAffinities" }}
requiredDuringSchedulingIgnoredDuringExecution:
  nodeSelectorTerms:
    - matchExpressions:
        - key: database
          operator: DoesNotExist
{{- if eq .Values.sandbox "true" }}
preferredDuringSchedulingIgnoredDuringExecution:
  - weight: 100
    preference:
      matchExpressions:
        - key: preemptible
          operator: NotIn
          values:
            - "false"
            - ""
  - weight: 100
    preference:
      matchExpressions:
        - key: preemptible
          operator: In
          values:
            - "true"
{{- end }}
{{- end }}

{{/*
Setup complete tasks queue info
*/}}
{{- define "sefaria.tasks.internalQueues" }}
tasks: {{ .Values.deployEnv }}-tasks
{{- if .Values.tasks.findRefs.enabled }}
findRefs: {{ .Values.deployEnv }}-find-refs
{{- end }}
{{- end }}
{{- define "sefaria.tasks.queues" }}
{{- merge  (fromYaml (include "sefaria.tasks.internalQueues" . )) .Values.tasks.queues | toYaml }}
{{- end }}

{{/*
Node affinity to avoid preemptible/spot GKE nodes.
Renders a nodeAffinity block from .Values.nonPreemptibleNodeAffinity.
Usage inside an existing affinity: block:
  {{- include "sefaria.nonPreemptibleNodeAffinity" . | nindent <N> }}
Usage when no affinity: block exists yet (wraps in affinity:):
  {{- include "sefaria.nonPreemptibleAffinityBlock" . | nindent <N> }}
*/}}
{{- define "sefaria.nonPreemptibleNodeAffinity" -}}
{{- with .Values.nonPreemptibleNodeAffinity }}
nodeAffinity:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end -}}

{{- define "sefaria.nonPreemptibleAffinityBlock" -}}
{{- with .Values.nonPreemptibleNodeAffinity }}
affinity:
  nodeAffinity:
    {{- toYaml . | nindent 4 }}
{{- end }}
{{- end -}}

{{/*
Render a KEDA ScaledObject for a given workload.
Defaults to targeting an Argo Rollout; override via $cfg.apiVersion and $cfg.kind for other resource types.
Usage: include "sefaria.keda.scaledobject" (list . "component" "target-name" .Values.keda.component)
*/}}
{{- define "sefaria.keda.scaledobject" -}}
{{- $ctx := index . 0 -}}
{{- $component := index . 1 -}}
{{- $targetName := index . 2 -}}
{{- $cfg := index . 3 -}}
{{- $keda := $ctx.Values.keda -}}
{{- $triggers := $cfg.triggers | default $keda.triggers -}}
---
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: {{ $ctx.Values.deployEnv }}-{{ $component }}
  labels:
    deployEnv: {{ $ctx.Values.deployEnv | quote }}
spec:
  scaleTargetRef:
    apiVersion: {{ $cfg.apiVersion | default "argoproj.io/v1alpha1" }}
    kind: {{ $cfg.kind | default "Rollout" }}
    name: {{ $targetName }}
  minReplicaCount: {{ $cfg.minReplicas | default $keda.minReplicas }}
  maxReplicaCount: {{ $cfg.maxReplicas | default $keda.maxReplicas }}
  pollingInterval: {{ $cfg.pollingInterval | default $keda.pollingInterval }}
  cooldownPeriod: {{ $cfg.cooldownPeriod | default $keda.cooldownPeriod }}
  triggers:
  {{- range $triggers }}
  - type: {{ .type }}
    metadata:
    {{- range $k, $v := .metadata }}
      {{ $k }}: {{ tpl ($v | toString) $ctx | quote }}
    {{- end }}
  {{- end }}
{{ end }}

{{- define "config.domainModules" }}
{{- $map := dict -}}
{{- $deployEnv := .Values.deployEnv -}}
{{- range .Values.domains.root }}
  {{- $codes := .code -}}
  {{- if not (kindIs "slice" $codes) -}}
    {{- $codes = list $codes -}}
  {{- end -}}
  {{- $rootDomain := tpl .url $ | quote | trimAll "\"" -}}
  {{- range $codes }}
    {{- $code := . -}}
    {{- $langMap := dict -}}
    {{- $_ := set $langMap "library" (printf "https://www.%s" $rootDomain) }}
    {{- range $.Values.domains.modules }}
      {{- $name := .name -}}
      {{- $subdomain := index .subdomains $code }}
      {{- if $subdomain }}
        {{- $fullDomain := printf "https://%s.%s" $subdomain $rootDomain }}
        {{- $_ := set $langMap $name $fullDomain }}
      {{- end }}
    {{- end }}
    {{- $_ := set $map $code $langMap }}
  {{- end }}
{{- end }}
{{- toYaml $map }}
{{- end }}

{{/*
The new reader client's environment (reader-next/src/lib/config.ts), for its pods in either layout: nodejs.mode "reader" (the node
pods are the reader) or "optin" (a separate reader rollout beside the legacy node pods). Args: (list $ctx $imageTag).
*/}}
{{- define "sefaria.readerEnv" -}}
{{- $ctx := index . 0 -}}
{{- $tag := index . 1 -}}
# reader-next/src/lib/config.ts: the API through this release's Varnish, with the public Host Django routes by
- name: SEFARIA_API_ORIGIN
  value: "http://varnish-{{ $ctx.Values.deployEnv }}-{{ $ctx.Release.Revision }}:8040"
- name: SEFARIA_API_HOST
  value: {{ printf "www.%s" (tpl (index $ctx.Values.domains.root 0).url $ctx) | quote }}
- name: PUBLIC_API_ORIGIN
  value: ""
- name: PUBLIC_SITE_ORIGIN
  value: ""
# this deployment's Voices (sheets made here live there)
- name: PUBLIC_VOICES_ORIGIN
  value: {{ printf "https://voices.%s" (tpl (index $ctx.Values.domains.root 0).url $ctx) | quote }}
- name: SEFARIA_PASS_THROUGH
  value: "1"
- name: PORT
  value: "3000"
# analytics IDs and the sign-in providers' public keys, as Django's pages use them (each optional; reader-next/src/lib/config.ts)
- name: APP_VERSION
  value: {{ $tag | quote }}
- name: SIMPLE_ANALYTICS_HOSTNAME
  value: {{ if eq (toString $ctx.Values.localSettings.DEBUG) "true" }}"sa-dev.sefaria.org"{{ else }}"sefaria.org"{{ end }}
{{- /* CHATBOT_API_BASE_URL: the Library Assistant's server, the value Django reads too (reader-next/src/lib/assistant/config.ts) */}}
{{- range list "GOOGLE_TAG_MANAGER_CODE" "GOOGLE_GTAG" "CLIENT_SENTRY_DSN" "GOOGLE_SSO_CLIENT_ID" "APPLE_SSO_CLIENT_ID" "RECAPTCHA_PUBLIC_KEY" "CHATBOT_API_BASE_URL" }}
- name: {{ . }}
  valueFrom:
    secretKeyRef:
      name: {{ $ctx.Values.secrets.localSettings.ref }}
      key: {{ . }}
      optional: true
{{- end }}
{{- end -}}
