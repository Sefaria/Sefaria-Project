{{- define "sefaria.secrets.googleClient" }}
{{- if .Values.web.secrets.googleClient.ref -}}
{{- .Values.web.secrets.googleClient.ref }}
{{- else -}}
google-client-secret-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.secrets.backupManager" }}
{{- if .Values.secrets.backupManager.ref -}}
{{- .Values.secrets.backupManager.ref }}
{{- else -}}
backup-manager-secret-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.secrets.logging" }}
{{- if .Values.web.secrets.logging.ref -}}
{{- .Values.web.secrets.logging.ref }}
{{- else -}}
logging-secret-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.secrets.varnish" }}
{{- if .Values.varnish.secrets.varnish.ref -}}
{{- .Values.varnish.secrets.varnish.ref }}
{{- else -}}
varnish-secret-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.secrets.schoolLookup" }}
{{- if .Values.web.secrets.schoolLookup.ref -}}
{{- .Values.web.secrets.schoolLookup.ref }}
{{- else -}}
school-lookup-data-{{ .Values.deployEnv }}
{{- end }}
{{- end }}


{{- define "sefaria.secrets.elasticCertificate" }}
{{- if .Values.web.secrets.elasticCertificate.ref -}}
{{- .Values.web.secrets.elasticCertificate.ref }}
{{- else -}}
elastic-certificate-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.secrets.elasticUser" }}
{{- if .Values.secrets.elasticUser.ref -}}
{{- .Values.secrets.elasticUser.ref }}
{{- else -}}
elastic-user-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.secrets.elasticAdmin" }}
{{- if .Values.secrets.elasticAdmin.ref -}}
{{- .Values.secrets.elasticAdmin.ref }}
{{- else -}}
elastic-admin-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.secrets.pgvectorPassword" }}
{{- if .Values.secrets.pgvectorPassword.ref -}}
{{- .Values.secrets.pgvectorPassword.ref }}
{{- else -}}
pgvector-secret-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.secrets.geminiApiKey" }}
{{- if .Values.secrets.geminiApiKey.ref -}}
{{- .Values.secrets.geminiApiKey.ref }}
{{- else -}}
gemini-api-key-{{ .Values.deployEnv }}
{{- end }}
{{- end }}

{{- define "sefaria.tarballName" }}
{{- if .Values.restore.tarball -}}
{{- .Values.restore.tarball }}
{{- else -}}
private_dump_small_{{ now | date "02.01.06" }}.tar.gz
{{- end }}
{{- end }}

{{/*
Expand the name of the chart.
*/}}
{{- define "sefaria.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "sefaria.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "sefaria.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "sefaria.labels" -}}
helm.sh/chart: {{ include "sefaria.chart" . }}
{{ include "sefaria.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "sefaria.selectorLabels" -}}
app.kubernetes.io/name: {{ include "sefaria.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Scheduling affinites applied to all pods
*/}}
{{- define "sefaria.nodeAffinities" }}
requiredDuringSchedulingIgnoredDuringExecution:
  nodeSelectorTerms:
    - matchExpressions:
        - key: database
          operator: DoesNotExist
{{- if eq .Values.sandbox "true" }}
preferredDuringSchedulingIgnoredDuringExecution:
  - weight: 100
    preference:
      matchExpressions:
        - key: preemptible
          operator: NotIn
          values:
            - "false"
            - ""
  - weight: 100
    preference:
      matchExpressions:
        - key: preemptible
          operator: In
          values:
            - "true"
{{- end }}
{{- end }}

{{/*
Setup complete tasks queue info
*/}}
{{- define "sefaria.tasks.internalQueues" }}
tasks: {{ .Values.deployEnv }}-tasks
{{- end }}
{{- define "sefaria.tasks.queues" }}
{{- merge  (fromYaml (include "sefaria.tasks.internalQueues" . )) .Values.tasks.queues | toYaml }}
{{- end }}

{{/*
Node affinity to avoid preemptible/spot GKE nodes.
Renders a nodeAffinity block from .Values.nonPreemptibleNodeAffinity.
Usage inside an existing affinity: block:
  {{- include "sefaria.nonPreemptibleNodeAffinity" . | nindent <N> }}
Usage when no affinity: block exists yet (wraps in affinity:):
  {{- include "sefaria.nonPreemptibleAffinityBlock" . | nindent <N> }}
*/}}
{{- define "sefaria.nonPreemptibleNodeAffinity" -}}
{{- with .Values.nonPreemptibleNodeAffinity }}
nodeAffinity:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end -}}

{{- define "sefaria.nonPreemptibleAffinityBlock" -}}
{{- with .Values.nonPreemptibleNodeAffinity }}
affinity:
  nodeAffinity:
    {{- toYaml . | nindent 4 }}
{{- end }}
{{- end -}}

{{/*
Render a KEDA ScaledObject for a given workload.
Defaults to targeting an Argo Rollout; override via $cfg.apiVersion and $cfg.kind for other resource types.
Usage: include "sefaria.keda.scaledobject" (list . "component" "target-name" .Values.keda.component)
*/}}
{{- define "sefaria.keda.scaledobject" -}}
{{- $ctx := index . 0 -}}
{{- $component := index . 1 -}}
{{- $targetName := index . 2 -}}
{{- $cfg := index . 3 -}}
{{- $keda := $ctx.Values.keda -}}
{{- $triggers := $cfg.triggers | default $keda.triggers -}}
---
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: {{ $ctx.Values.deployEnv }}-{{ $component }}
  labels:
    deployEnv: {{ $ctx.Values.deployEnv | quote }}
spec:
  scaleTargetRef:
    apiVersion: {{ $cfg.apiVersion | default "argoproj.io/v1alpha1" }}
    kind: {{ $cfg.kind | default "Rollout" }}
    name: {{ $targetName }}
  minReplicaCount: {{ $cfg.minReplicas | default $keda.minReplicas }}
  maxReplicaCount: {{ $cfg.maxReplicas | default $keda.maxReplicas }}
  pollingInterval: {{ $cfg.pollingInterval | default $keda.pollingInterval }}
  cooldownPeriod: {{ $cfg.cooldownPeriod | default $keda.cooldownPeriod }}
  triggers:
  {{- range $triggers }}
  - type: {{ .type }}
    metadata:
    {{- range $k, $v := .metadata }}
      {{ $k }}: {{ tpl ($v | toString) $ctx | quote }}
    {{- end }}
  {{- end }}
{{ end }}

{{- define "config.domainModules" }}
{{- $map := dict -}}
{{- $deployEnv := .Values.deployEnv -}}
{{- range .Values.domains.root }}
  {{- $codes := .code -}}
  {{- if not (kindIs "slice" $codes) -}}
    {{- $codes = list $codes -}}
  {{- end -}}
  {{- $rootDomain := tpl .url $ | quote | trimAll "\"" -}}
  {{- range $codes }}
    {{- $code := . -}}
    {{- $langMap := dict -}}
    {{- $_ := set $langMap "library" (printf "https://www.%s" $rootDomain) }}
    {{- range $.Values.domains.modules }}
      {{- $name := .name -}}
      {{- $subdomain := index .subdomains $code }}
      {{- if $subdomain }}
        {{- $fullDomain := printf "https://%s.%s" $subdomain $rootDomain }}
        {{- $_ := set $langMap $name $fullDomain }}
      {{- end }}
    {{- end }}
    {{- $_ := set $map $code $langMap }}
  {{- end }}
{{- end }}
{{- toYaml $map }}
{{- end }}

{{- define "sefaria.secrets.authServicePg" }}
{{- required "authService.postgres.secrets.dsn.ref: the cluster key-registry Secret" .Values.authService.postgres.secrets.dsn.ref }}
{{- end }}

{{- define "sefaria.authService.jwksURL" -}}
{{- $svc := default (printf "mint-%s" .Values.deployEnv) .Values.authService.jwt.jwks.service -}}
http://{{ $svc }}.{{ .Release.Namespace }}.svc.cluster.local:{{ .Values.authService.jwt.jwks.port }}{{ .Values.authService.jwt.jwks.path }}
{{- end }}

{{- define "sefaria.authService.issuer" -}}
{{- default (printf "https://mint-%s.%s.svc.cluster.local" .Values.deployEnv .Release.Namespace) .Values.authService.jwt.issuer -}}
{{- end }}
